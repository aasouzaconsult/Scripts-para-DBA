USE [CLR]
/***************************************************************************************************
 * FINALIDADE ..: Retorna informações de um arquivo utilizando o FileSystemObject
 * CRIADO POR ..: Dirceu Moraes Resende Filho
 * CRIADO EM ...: 07/01/2014
***************************************************************************************************/
CREATE PROCEDURE [dbo].stpInformacoes_Arquivo_FSO(@strArquivo VARCHAR(255))
AS
BEGIN

	DECLARE
		@hr INT,
		@objFileSystem INT,
		@objFile INT,
		@ErrorObject INT,
		@ErrorMessage VARCHAR(255),
		@Path VARCHAR(255),--
		@ShortPath VARCHAR(255),
		@Type VARCHAR(100),
		@DateCreated DATETIME,
		@DateLastAccessed DATETIME,
		@DateLastModified DATETIME,
		@Attributes INT,
		@size INT



	SET nocount ON

	SELECT
		@hr = 0,
		@errorMessage = 'opening the file system object '
	
	EXEC @hr = sp_OACreate
		'Scripting.FileSystemObject',
		@objFileSystem OUT
		
	IF @hr = 0
		SELECT
			@errorMessage = 'accessing the file ''' + @strArquivo + '''',
			@ErrorObject = @objFileSystem
	
	IF @hr = 0
		EXEC @hr = sp_OAMethod
			@objFileSystem,
			'GetFile',
			@objFile OUT,
			@strArquivo
			
	IF @hr = 0
		SELECT
			@errorMessage = 'getting the attributes of ''' + @strArquivo + '''',
			@ErrorObject = @objFile
			
	IF @hr = 0
		EXEC @hr = sp_OAGetProperty
			@objFile,
			'Path',
			@path OUT
			
	IF @hr = 0
		EXEC @hr = sp_OAGetProperty
			@objFile,
			'ShortPath',
			@ShortPath OUT
			
	IF @hr = 0
		EXEC @hr = sp_OAGetProperty
			@objFile,
			'Type',
			@Type OUT
			
	IF @hr = 0
		EXEC @hr = sp_OAGetProperty
			@objFile,
			'DateCreated',
			@DateCreated OUT
			
	IF @hr = 0
		EXEC @hr = sp_OAGetProperty
			@objFile,
			'DateLastAccessed',
			@DateLastAccessed OUT
			
	IF @hr = 0
		EXEC @hr = sp_OAGetProperty
			@objFile,
			'DateLastModified',
			@DateLastModified OUT
			
	IF @hr = 0
		EXEC @hr = sp_OAGetProperty
			@objFile,
			'Attributes',
			@Attributes OUT
			
	IF @hr = 0
		EXEC @hr = sp_OAGetProperty
			@objFile,
			'size',
			@size OUT


	IF @hr <> 0
	BEGIN
		DECLARE
			@Source VARCHAR(255),
			@Description VARCHAR(255),
			@Helpfile VARCHAR(255),
			@HelpID INT
   
		EXECUTE sp_OAGetErrorInfo
			@errorObject,
			@source OUTPUT,
			@Description OUTPUT,
			@Helpfile OUTPUT,
			@HelpID OUTPUT

		SELECT
			@ErrorMessage = 'Error whilst ' + @Errormessage + ', ' + @Description
			
		RAISERROR (@ErrorMessage,16,1)
		
	END
	
	EXEC sp_OADestroy
		@objFileSystem
		
	EXEC sp_OADestroy
		@objFile
		
	SELECT
		[Path] = @Path,
		[ShortPath] = @ShortPath,
		[Type] = @Type,
		[DateCreated] = @DateCreated,
		[DateLastAccessed] = @DateLastAccessed,
		[DateLastModified] = @DateLastModified,
		[Attributes] = @Attributes,
		[Size] = @size
		
	RETURN @hr

END

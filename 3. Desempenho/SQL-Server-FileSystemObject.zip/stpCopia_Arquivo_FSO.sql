SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
GO
/***************************************************************************************************
 * FINALIDADE ..: Copiar um arquivo utilizando o FileSystemObject ao inv�s do CLR
 * CRIADO POR ..: Dirceu Moraes Resende Filho
 * CRIADO EM ...: 22/01/2014
***************************************************************************************************/
CREATE PROCEDURE [dbo].[stpCopia_Arquivo_FSO] (
		@strOrigem VARCHAR(MAX),
		@strDestino VARCHAR(MAX),
		@sobrescrever INT = 0
	)
AS
BEGIN

	IF (CLR.dbo.fncArquivo_Existe(@strOrigem) = 1 AND @strOrigem != @strDestino)
	BEGIN

		DECLARE	
			@hr INT,
			@objFileSystem INT,
			@source VARCHAR(250),
			@description VARCHAR(2000)


		EXEC @hr = sp_OACreate
			'Scripting.FileSystemObject',
			@objFileSystem OUT
			
			
		IF @hr <> 0
		BEGIN
		
			EXEC sp_OAGetErrorInfo
				@objFileSystem,
				@source OUT,
				@description OUT
				
			RAISERROR('Object Creation Failed 0x%x, %s, %s',16,1,@hr,@source,@description)
			
			RETURN
		END

		
		IF (CLR.dbo.fncArquivo_Existe(@strDestino) = 1)
			IF (@sobrescrever = 1) 
				EXEC CLR.dbo.stpApaga_Arquivo_FSO @strDestino
			ELSE
			BEGIN
				PRINT 'O arquivo de destino j� existe e o par�metro sobrescrever foi definido como N�O'
				RETURN
			END
			
		
		
		EXEC @hr = sp_OAMethod
			@objFileSystem,
			'CopyFile',
			NULL,
			@strOrigem,
			@strDestino
			
		IF (@hr <> 0)
		BEGIN
		
			EXEC sp_OAGetErrorInfo
				@objFileSystem,
				@source OUT,
				@description OUT
				
			EXEC sp_OADestroy
				@objFileSystem
				
			RAISERROR('Method Failed 0x%x, %s, %s',16, 1, @hr, @source, @description)
			
			PRINT @source
			PRINT @description
			
			RETURN
			
		END
		
		
		EXEC sp_OADestroy
			@objFileSystem
		
	END
	ELSE
		PRINT 'O arquivo de origem n�o existe ou � igual ao arquivo de destino'

END 
GO

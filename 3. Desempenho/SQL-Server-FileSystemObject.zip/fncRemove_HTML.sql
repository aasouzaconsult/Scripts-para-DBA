/***************************************************************************************************
 * FINALIDADE ..: Remover tags HTML em uma string
 * CRIADO POR ..: Dirceu Moraes Resende Filho (SLE)
 * CRIADO EM ...: 01/01/2014
***************************************************************************************************/
ALTER FUNCTION [dbo].[fncRemove_HTML] (@HTMLText VARCHAR(MAX))
RETURNS VARCHAR(MAX)
AS
BEGIN

	DECLARE	@Start INT
	DECLARE	@End INT
	DECLARE	@Length INT

	-- Substitui a entidade HTML "&amp;" pelo caracter '&'
	SET @Start = CHARINDEX('&amp;', @HTMLText)
	SET @End = @Start + 4
	SET @Length = (@End - @Start) + 1

	WHILE (@Start > 0 AND @End > 0 AND @Length > 0)
	BEGIN
		SET @HTMLText = STUFF(@HTMLText, @Start, @Length, '&')
		SET @Start = CHARINDEX('&amp;', @HTMLText)
		SET @End = @Start + 4
		SET @Length = (@End - @Start) + 1
	END

	-- Substitui a entidade HTML "&lt;" pelo caracter '<'
	SET @Start = CHARINDEX('&lt;', @HTMLText)
	SET @End = @Start + 3
	SET @Length = (@End - @Start) + 1

	WHILE (@Start > 0 AND @End > 0 AND @Length > 0) 
	BEGIN
		SET @HTMLText = STUFF(@HTMLText, @Start, @Length, '<')
		SET @Start = CHARINDEX('&lt;', @HTMLText)
		SET @End = @Start + 3
		SET @Length = (@End - @Start) + 1
	END

	-- Substitui a entidade HTML "&gt;" pelo caracter '>'
	SET @Start = CHARINDEX('&gt;', @HTMLText)
	SET @End = @Start + 3
	SET @Length = (@End - @Start) + 1

	WHILE (@Start > 0 AND @End > 0 AND @Length > 0)
	BEGIN
		SET @HTMLText = STUFF(@HTMLText, @Start, @Length, '>')
		SET @Start = CHARINDEX('&gt;', @HTMLText)
		SET @End = @Start + 3
		SET @Length = (@End - @Start) + 1
	END

	-- Substitui a entidade HTML "&amp;&amp;" pelo caracter '&'
	SET @Start = CHARINDEX('&amp;amp;', @HTMLText)
	SET @End = @Start + 4
	SET @Length = (@End - @Start) + 1

	WHILE (@Start > 0 AND @End > 0 AND @Length > 0)
	BEGIN
		SET @HTMLText = STUFF(@HTMLText, @Start, @Length, '&')
		SET @Start = CHARINDEX('&amp;amp;', @HTMLText)
		SET @End = @Start + 4
		SET @Length = (@End - @Start) + 1
	END

	-- Substitui a entidade HTML "&nbsp;" pelo caracter ' '
	SET @Start = CHARINDEX('&nbsp;', @HTMLText)
	SET @End = @Start + 5
	SET @Length = (@End - @Start) + 1

	WHILE (@Start > 0 AND @End > 0 AND @Length > 0)
	BEGIN
		SET @HTMLText = STUFF(@HTMLText, @Start, @Length, ' ')
		SET @Start = CHARINDEX('&nbsp;', @HTMLText)
		SET @End = @Start + 5
		SET @Length = (@End - @Start) + 1
	END

	-- Substitui a tag <br> pela sequ�ncia de nova linha (CHR(13) + CHR(10))
	SET @Start = CHARINDEX('<br>', @HTMLText)
	SET @End = @Start + 3
	SET @Length = (@End - @Start) + 1

	WHILE (@Start > 0 AND @End > 0 AND @Length > 0)
	BEGIN
		SET @HTMLText = STUFF(@HTMLText, @Start, @Length, CHAR(13) + CHAR(10))
		SET @Start = CHARINDEX('<br>', @HTMLText)
		SET @End = @Start + 3
		SET @Length = (@End - @Start) + 1
	END


	-- Substitui a tag <br/> pela sequ�ncia de nova linha (CHR(13) + CHR(10))
	SET @Start = CHARINDEX('<br/>', @HTMLText)
	SET @End = @Start + 4
	SET @Length = (@End - @Start) + 1

	WHILE (@Start > 0 AND @End > 0 AND @Length > 0)
	BEGIN
		SET @HTMLText = STUFF(@HTMLText, @Start, @Length, 'CHAR(13) + CHAR(10)')
		SET @Start = CHARINDEX('<br/>', @HTMLText)
		SET @End = @Start + 4
		SET @Length = (@End - @Start) + 1
	END

	-- Substitui a tag <br /> pela sequ�ncia de nova linha (CHR(13) + CHR(10))
	SET @Start = CHARINDEX('<br />', @HTMLText)
	SET @End = @Start + 5
	SET @Length = (@End - @Start) + 1

	WHILE (@Start > 0 AND @End > 0 AND @Length > 0)
	BEGIN
		SET @HTMLText = STUFF(@HTMLText, @Start, @Length, 'CHAR(13) + CHAR(10)')
		SET @Start = CHARINDEX('<br />', @HTMLText)
		SET @End = @Start + 5
		SET @Length = (@End - @Start) + 1
	END


	-- Remove os par�metros contidos nas tags HTML
	SET @Start = CHARINDEX('<', @HTMLText)
	SET @End = CHARINDEX('>', @HTMLText, CHARINDEX('<', @HTMLText))
	SET @Length = (@End - @Start) + 1

	WHILE (@Start > 0 AND @End > 0 AND @Length > 0)
	BEGIN
		SET @HTMLText = STUFF(@HTMLText, @Start, @Length, '')
		SET @Start = CHARINDEX('<', @HTMLText)
		SET @End = CHARINDEX('>', @HTMLText, CHARINDEX('<', @HTMLText))
		SET @Length = (@End - @Start) + 1
	END

	
	RETURN LTRIM(RTRIM(@HTMLText))
	

END
